"""
Utility functions for the Agentic Campaign Optimizer
Includes data processing, analysis, and AI agent simulation.
"""

import pandas as pd
import numpy as np
from typing import Tuple, List, Dict
import json


def load_marketing_data(filepath: str = 'marketing_campaign_data.csv') -> pd.DataFrame:
    """
    Load marketing campaign data from CSV.
    
    Args:
        filepath: Path to the CSV file
    
    Returns:
        pd.DataFrame: Marketing campaign data
    """
    try:
        df = pd.read_csv(filepath)
        return df
    except FileNotFoundError:
        print(f"Error: {filepath} not found. Run generate_data.py first.")
        return None


def get_segment_performance(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate performance metrics by audience segment.
    
    Args:
        df: Marketing campaign data
    
    Returns:
        pd.DataFrame: Aggregated metrics by segment
    """
    segment_stats = df.groupby('Audience_Segment').agg({
        'Spend_USD': 'sum',
        'Impressions': 'sum',
        'Clicks': 'sum',
        'Conversions': 'sum',
        'Revenue_USD': 'sum',
        'Campaign_ID': 'count'  # Number of campaigns
    }).reset_index()
    
    segment_stats.rename(columns={'Campaign_ID': 'Num_Campaigns'}, inplace=True)
    
    # Calculate metrics
    segment_stats['Avg_CTR_Percent'] = (segment_stats['Clicks'] / segment_stats['Impressions'] * 100).round(2)
    segment_stats['Avg_CPA_USD'] = (segment_stats['Spend_USD'] / segment_stats['Conversions']).round(2)
    segment_stats['Avg_ROAS'] = (segment_stats['Revenue_USD'] / segment_stats['Spend_USD']).round(2)
    
    return segment_stats.sort_values('Avg_CPA_USD', ascending=False)


def get_platform_performance(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate performance metrics by platform.
    
    Args:
        df: Marketing campaign data
    
    Returns:
        pd.DataFrame: Aggregated metrics by platform
    """
    platform_stats = df.groupby('Platform').agg({
        'Spend_USD': 'sum',
        'Impressions': 'sum',
        'Clicks': 'sum',
        'Conversions': 'sum',
        'Revenue_USD': 'sum',
        'Campaign_ID': 'count'
    }).reset_index()
    
    platform_stats.rename(columns={'Campaign_ID': 'Num_Campaigns'}, inplace=True)
    
    # Calculate metrics
    platform_stats['Avg_CTR_Percent'] = (platform_stats['Clicks'] / platform_stats['Impressions'] * 100).round(2)
    platform_stats['Avg_CPA_USD'] = (platform_stats['Spend_USD'] / platform_stats['Conversions']).round(2)
    platform_stats['Avg_ROAS'] = (platform_stats['Revenue_USD'] / platform_stats['Spend_USD']).round(2)
    
    return platform_stats.sort_values('Avg_ROAS', ascending=False)


def identify_underperformers(df: pd.DataFrame, cpa_threshold: float = 50, ctr_threshold: float = 0.5) -> pd.DataFrame:
    """
    Identify underperforming audience segments based on CPA and CTR thresholds.
    
    Args:
        df: Marketing campaign data
        cpa_threshold: CPA above this is considered poor
        ctr_threshold: CTR below this is considered poor
    
    Returns:
        pd.DataFrame: Underperforming segments with anomaly flags
    """
    segment_performance = get_segment_performance(df)
    
    # Flag underperformers
    underperformers = segment_performance[
        (segment_performance['Avg_CPA_USD'] > cpa_threshold) | 
        (segment_performance['Avg_CTR_Percent'] < ctr_threshold)
    ].copy()
    
    # Add severity score
    underperformers['Severity_Score'] = (
        (underperformers['Avg_CPA_USD'] / cpa_threshold) + 
        ((ctr_threshold / underperformers['Avg_CTR_Percent']).replace([np.inf, -np.inf], 0))
    ).round(2)
    
    return underperformers.sort_values('Severity_Score', ascending=False)


def get_underperforming_segments(df: pd.DataFrame) -> List[str]:
    """
    Get list of underperforming segment names for dropdown.
    
    Args:
        df: Marketing campaign data
    
    Returns:
        List of segment names
    """
    underperformers = identify_underperformers(df)
    return underperformers['Audience_Segment'].tolist()


def simulate_ai_agent_analysis(segment: str, df: pd.DataFrame) -> Dict:
    """
    Simulate an AI agent analyzing an underperforming segment.
    Generates creative analysis and ad copy variants.
    
    Args:
        segment: Audience segment name
        df: Marketing campaign data
    
    Returns:
        Dict with analysis and creative variants
    """
    # Get segment data
    segment_data = df[df['Audience_Segment'] == segment]
    segment_stats = get_segment_performance(df)
    segment_stats = segment_stats[segment_stats['Audience_Segment'] == segment].iloc[0]
    
    # Determine why it's failing (simplified logic)
    analysis_reasons = {
        'Tech Bros 25-34': "High-income tech professionals are attracted to innovative, cutting-edge solutions with ROI metrics. Current creative lacks technical depth and urgency.",
        'Soccer Moms 35-45': "This demographic values family-focused benefits, time-saving, and affordability. Current messaging is too tech-heavy and doesn't address real pain points.",
        'Retirees 55-65': "Seniors seek simplicity, security, and ease of use. Current creative uses jargon and small fonts that don't resonate with this age group.",
        'College Students 18-24': "Young adults want trendy, social-proof heavy messaging with peer endorsements. Current ads lack relatability and seem corporate.",
        'Young Professionals 30-40': "This group values career growth and work-life balance. Messaging should emphasize productivity and lifestyle benefits.",
        'Corporate Executives 40-55': "C-suite leaders want bottom-line impact and strategic value. Focus on ROI, efficiency, and competitive advantage."
    }
    
    # Creative variants tailored to segment
    creative_variants = {
        'Tech Bros 25-34': [
            {
                'headline': '10x Your Productivity with AI-Powered Automation',
                'primary_text': 'Join 10K+ developers using our platform to cut ops time by 75%. Real-time analytics, 99.99% uptime, enterprise-grade security. Get started free.'
            },
            {
                'headline': 'The Stack That Powers Y Combinator Companies',
                'primary_text': 'Used by Stripe, Figma, and more. Advanced API, webhooks, and 50+ integrations. Scale from MVP to Series C without rebuilding.'
            },
            {
                'headline': 'Cut Deployment Time from Hours to Minutes',
                'primary_text': 'Zero-config deployments, automatic scaling, built-in CI/CD. Focus on code, not infrastructure. Try free for 14 days.'
            }
        ],
        'Soccer Moms 35-45': [
            {
                'headline': 'Save 5 Hours a Week—Guaranteed',
                'primary_text': 'Moms are using our app to manage family schedules, finances, and wellness in one place. Save time for what matters most. Join the community.'
            },
            {
                'headline': 'Peace of Mind for Busy Families',
                'primary_text': 'One app for healthcare, school, and family coordination. 1M+ moms trust us daily. See how real families are saving time and money.'
            },
            {
                'headline': 'Your Family Deserves Better Than 10 Different Apps',
                'primary_text': 'All-in-one family hub with shared calendars, budgets, and alerts. Start organizing today. First month 50% off.'
            }
        ],
        'Retirees 55-65': [
            {
                'headline': 'Simple. Secure. For Your Peace of Mind.',
                'primary_text': 'Large text, easy navigation, U.S.-based support team. Keep your finances and health records safe. Call or click to get started.'
            },
            {
                'headline': 'Easy Tech Support from Real People',
                'primary_text': 'Frustrated with complicated apps? We offer phone support, simple design, and plain-English explanations. Try free for 30 days.'
            },
            {
                'headline': 'Trusted by 500K+ Seniors & Their Families',
                'primary_text': 'Designed for simplicity. Built for security. No hidden fees. Get started with a free consultation call with a specialist.'
            }
        ],
        'College Students 18-24': [
            {
                'headline': '1000s of Your Classmates Are Already Using This',
                'primary_text': 'See what everyone on campus is doing. Exclusive student discount: 80% off first year. Join the community now.'
            },
            {
                'headline': 'The #1 App Your Friends Recommended',
                'primary_text': 'Trending on TikTok & Instagram. Real student reviews: 4.9⭐. Limited-time offer: Free premium for 3 months.'
            },
            {
                'headline': 'Save Money, Earn Cash, Join the Movement',
                'primary_text': 'College exclusive. Cashback on every purchase. Refer friends and earn $20 each. Download now and get $10 bonus credit.'
            }
        ],
        'Young Professionals 30-40': [
            {
                'headline': 'Reclaim 10 Hours of Your Week',
                'primary_text': 'Professionals like you are automating busy work to focus on career growth. See real ROI in 30 days or money back.'
            },
            {
                'headline': 'Level Up Your Career While Working Smarter',
                'primary_text': 'Used by managers at Fortune 500s to boost team productivity and visibility. Free strategy session included.'
            },
            {
                'headline': 'Work-Life Balance Starts with Better Tools',
                'primary_text': 'Streamline your workflow and leave the office on time. Join 50K+ professionals. Claim your free personalized demo.'
            }
        ],
        'Corporate Executives 40-55': [
            {
                'headline': '30% Average Cost Reduction in Year 1',
                'primary_text': 'C-suite executives reduce operational costs and accelerate time-to-value. Enterprise security, dedicated support, guaranteed uptime.'
            },
            {
                'headline': 'Transform Your Enterprise in 90 Days',
                'primary_text': 'Proven with Cisco, Dell, and Global 2000 companies. Measurable results: 40% faster deployment, 35% cost savings.'
            },
            {
                'headline': 'Competitive Advantage Through Operational Excellence',
                'primary_text': 'Strategic tool for growth-focused executives. Schedule a confidential briefing with our VP Sales. Enterprise solutions designed for scale.'
            }
        ]
    }
    
    # Get default variants if segment not in dict
    reason = analysis_reasons.get(segment, "This segment needs targeted messaging aligned with their core values and pain points.")
    variants = creative_variants.get(segment, [
        {
            'headline': 'Targeted Offer for Your Audience',
            'primary_text': 'Customized solution designed for your needs. Get started today and see immediate results.'
        },
        {
            'headline': 'Special Offer Just for You',
            'primary_text': 'Limited time opportunity. Join thousands of satisfied customers who have already made the switch.'
        },
        {
            'headline': 'Your Success Story Starts Here',
            'primary_text': 'Proven results, dedicated support, and guaranteed satisfaction. Learn why we\'re the #1 choice.'
        }
    ])
    
    return {
        'segment': segment,
        'current_metrics': {
            'spend': round(segment_stats['Spend_USD'], 2),
            'conversions': int(segment_stats['Conversions']),
            'cpa': round(segment_stats['Avg_CPA_USD'], 2),
            'ctr': round(segment_stats['Avg_CTR_Percent'], 2),
            'roas': round(segment_stats['Avg_ROAS'], 2)
        },
        'analysis': reason,
        'recommendations': [
            'Focus on emotional triggers and pain points specific to this demographic',
            'Test simplified messaging that emphasizes key benefits',
            'Consider reducing ad spend and reallocating to high-performing segments'
        ],
        'creative_variants': variants
    }


def calculate_budget_reallocation(df: pd.DataFrame, reallocation_percentage: float = 0.2) -> Tuple[pd.DataFrame, pd.DataFrame, Dict]:
    """
    Calculate recommended budget reallocation strategy.
    
    Args:
        df: Marketing campaign data
        reallocation_percentage: Percentage of budget to reallocate from underperformers
    
    Returns:
        Tuple of (current_allocation, recommended_allocation, projections)
    """
    segment_performance = get_segment_performance(df)
    
    # Current allocation
    current = segment_performance[['Audience_Segment', 'Spend_USD', 'Conversions', 'Avg_CPA_USD', 'Avg_ROAS']].copy()
    current.rename(columns={'Spend_USD': 'Current_Spend'}, inplace=True)
    
    # Identify top performers and underperformers
    top_performers = current.nlargest(3, 'Avg_ROAS')
    underperformers = identify_underperformers(df)
    
    # Calculate reallocation
    total_underperformer_spend = underperformers['Spend_USD'].sum()
    reallocation_amount = total_underperformer_spend * reallocation_percentage
    
    # New allocation
    recommended = current.copy()
    recommended['Recommended_Spend'] = recommended['Current_Spend'].copy()
    
    # Reduce spending for underperformers
    for segment in underperformers['Audience_Segment']:
        current_spend = recommended[recommended['Audience_Segment'] == segment]['Current_Spend'].values[0]
        reduction = current_spend * reallocation_percentage
        recommended.loc[recommended['Audience_Segment'] == segment, 'Recommended_Spend'] -= reduction
    
    # Distribute reallocation to top performers
    if len(top_performers) > 0:
        per_performer = reallocation_amount / len(top_performers)
        for segment in top_performers['Audience_Segment']:
            recommended.loc[recommended['Audience_Segment'] == segment, 'Recommended_Spend'] += per_performer
    
    # Calculate projections
    current['Projected_Conversions'] = current['Conversions']
    recommended['Projected_Conversions'] = (
        recommended['Recommended_Spend'] / recommended['Avg_CPA_USD']
    ).round(0)
    
    current_total_conversions = current['Projected_Conversions'].sum()
    recommended_total_conversions = recommended['Projected_Conversions'].sum()
    conversion_lift = recommended_total_conversions - current_total_conversions
    conversion_lift_pct = (conversion_lift / current_total_conversions * 100) if current_total_conversions > 0 else 0
    
    projections = {
        'current_spend': round(current['Current_Spend'].sum(), 2),
        'recommended_spend': round(recommended['Recommended_Spend'].sum(), 2),
        'current_conversions': int(current_total_conversions),
        'projected_conversions': int(recommended_total_conversions),
        'conversion_lift': int(conversion_lift),
        'conversion_lift_pct': round(conversion_lift_pct, 1),
        'reallocation_amount': round(reallocation_amount, 2)
    }
    
    return current, recommended, projections
