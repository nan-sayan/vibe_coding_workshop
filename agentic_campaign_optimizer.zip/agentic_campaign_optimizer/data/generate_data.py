"""
Dummy Data Generation for Agentic Campaign Optimizer
Generates realistic marketing campaign data with intentional underperformers.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_marketing_data(n_rows=500):
    """
    Generate a realistic marketing campaign dataset with 500+ rows.
    
    Args:
        n_rows: Number of rows to generate (default 500)
    
    Returns:
        pd.DataFrame: Marketing campaign data with calculated metrics
    """
    np.random.seed(42)
    
    # Define base parameters
    platforms = ['Meta', 'Google', 'LinkedIn']
    segments = [
        'Tech Bros 25-34',
        'Soccer Moms 35-45',
        'Retirees 55-65',
        'College Students 18-24',
        'Young Professionals 30-40',
        'Corporate Executives 40-55'
    ]
    
    creative_names = [
        'Summer Sale Push',
        'Limited Time Offer',
        'Exclusive Deal',
        'Premium Features',
        'Get Started Free',
        'Join Our Community',
        'Black Friday Early',
        'Last Chance Alert',
        'New Product Launch',
        'VIP Membership'
    ]
    
    data = []
    start_date = datetime.now() - timedelta(days=90)
    
    for i in range(n_rows):
        campaign_id = f"CAMP_{i+1:04d}"
        platform = np.random.choice(platforms)
        segment = np.random.choice(segments)
        creative = np.random.choice(creative_names)
        
        # Base spend varies by platform and segment
        base_spend = np.random.uniform(500, 5000)
        
        # Intentionally create underperformers: "Soccer Moms 35-45" and "Retirees 55-65"
        # These segments will have terrible performance metrics
        if segment == 'Soccer Moms 35-45':
            # Very poor performance
            impressions = np.random.uniform(2000, 5000)
            clicks = impressions * np.random.uniform(0.002, 0.005)  # 0.2-0.5% CTR
            conversions = clicks * np.random.uniform(0.01, 0.03)    # 1-3% conversion rate
            revenue = conversions * np.random.uniform(15, 25)       # Low AOV
        elif segment == 'Retirees 55-65':
            # Very poor performance
            impressions = np.random.uniform(3000, 6000)
            clicks = impressions * np.random.uniform(0.001, 0.004)  # 0.1-0.4% CTR
            conversions = clicks * np.random.uniform(0.005, 0.02)   # 0.5-2% conversion rate
            revenue = conversions * np.random.uniform(10, 20)       # Low AOV
        else:
            # Good performance for other segments
            impressions = np.random.uniform(8000, 20000)
            clicks = impressions * np.random.uniform(0.02, 0.08)    # 2-8% CTR
            conversions = clicks * np.random.uniform(0.05, 0.15)    # 5-15% conversion rate
            revenue = conversions * np.random.uniform(60, 150)      # Higher AOV
        
        # Calculate metrics
        ctr = (clicks / impressions) * 100 if impressions > 0 else 0
        cpa = base_spend / conversions if conversions > 0 else base_spend
        roas = revenue / base_spend if base_spend > 0 else 0
        
        # Random date within the last 90 days
        date = start_date + timedelta(days=np.random.randint(0, 90))
        
        data.append({
            'Campaign_ID': campaign_id,
            'Date': date.strftime('%Y-%m-%d'),
            'Platform': platform,
            'Audience_Segment': segment,
            'Ad_Creative_Name': creative,
            'Spend_USD': round(base_spend, 2),
            'Impressions': int(impressions),
            'Clicks': int(clicks),
            'Conversions': int(conversions),
            'Revenue_USD': round(revenue, 2),
            'CTR_Percent': round(ctr, 2),
            'CPA_USD': round(cpa, 2),
            'ROAS': round(roas, 2)
        })
    
    df = pd.DataFrame(data)
    return df


def save_data_to_excel(df, filepath='marketing_campaign_data.xlsx'):
    """
    Save the generated data to an Excel file.
    
    Args:
        df: DataFrame to save
        filepath: Output file path
    """
    # Create Excel writer with formatting
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Campaign Data', index=False)
        
        # Get the workbook and worksheet
        workbook = writer.book
        worksheet = writer.sheets['Campaign Data']
        
        # Auto-adjust column widths
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            worksheet.column_dimensions[column_letter].width = adjusted_width
    
    print(f"Data saved to {filepath}")


if __name__ == "__main__":
    # Generate data
    df = generate_marketing_data(500)
    
    # Display summary
    print("Generated Marketing Campaign Data Summary:")
    print(f"Shape: {df.shape}")
    print(f"\nColumns: {df.columns.tolist()}")
    print(f"\nFirst few rows:")
    print(df.head())
    print(f"\nData types:\n{df.dtypes}")
    print(f"\nBasic Statistics:")
    print(df[['Spend_USD', 'Impressions', 'Clicks', 'Conversions', 'CTR_Percent', 'CPA_USD', 'ROAS']].describe())
    
    # Save to Excel
    save_data_to_excel(df, 'marketing_campaign_data.xlsx')
    
    # Also save as CSV for easy loading in Streamlit
    df.to_csv('marketing_campaign_data.csv', index=False)
    print("\nData also saved to marketing_campaign_data.csv")
